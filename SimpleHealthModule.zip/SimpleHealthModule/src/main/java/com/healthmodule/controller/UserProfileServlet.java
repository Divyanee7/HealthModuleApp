package com.healthmodule.controller;


import com.healthmodule.dao.UserProfileDAO;
import com.healthmodule.model.UserProfile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/saveProfile")
public class UserProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
	private UserProfileDAO userProfileDAO;

    public void init() {
        userProfileDAO = new UserProfileDAO();
    }

    // Handle GET request
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.jsp"); // Redirect to the profile form (index.jsp)
    }

    // Handle POST request
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int age = Integer.parseInt(request.getParameter("age"));
        float weight = Float.parseFloat(request.getParameter("weight"));
        float height = Float.parseFloat(request.getParameter("height"));
        String activityLevel = request.getParameter("activityLevel");
        float bmi = calculateBMI(weight, height);

        UserProfile userProfile = new UserProfile();
        userProfile.setAge(age);
        userProfile.setWeight(weight);
        userProfile.setHeight(height);
        userProfile.setActivityLevel(activityLevel);
        userProfile.setBmi(bmi);

        try {
            userProfileDAO.saveUserProfile(userProfile);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.sendRedirect("bmi.jsp?bmi=" + bmi); // Redirect to the BMI calculation page
    }

    private float calculateBMI(float weight, float height) {
        return weight / (height * height);
    }
}
