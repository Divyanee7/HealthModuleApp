package com.healthmodule.dao;


import com.healthmodule.model.UserProfile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserProfileDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/health_db";
    private String jdbcUsername = "root";
    private String jdbcPassword = "@Geeta@2002";

    private static final String INSERT_USER_SQL = "INSERT INTO user_profile (age, weight, height, activity_level, bmi) VALUES (?, ?, ?, ?, ?);";

    protected Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void saveUserProfile(UserProfile profile) throws SQLException {
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_SQL)) {
            preparedStatement.setInt(1, profile.getAge());
            preparedStatement.setFloat(2, profile.getWeight());
            preparedStatement.setFloat(3, profile.getHeight());
            preparedStatement.setString(4, profile.getActivityLevel());
            preparedStatement.setFloat(5, profile.getBmi());
            preparedStatement.executeUpdate();
        }
    }
}
